package com;

public class ReverseString {

	static void nameReve(String anyString) {

		char[] str = anyString.toCharArray();

		for (int i = str.length - 1; i >= 0; i--)
			System.out.print(str[i]);
	}

	public static void main(String[] args) {
		nameReve("najus");

	}
}