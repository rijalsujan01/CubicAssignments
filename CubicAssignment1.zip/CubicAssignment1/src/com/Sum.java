package com;

public class Sum {

	public static void main(String[] args) {
		int a = 100;
		Double b = 300.00;
		double a1 = a; //TypeCasting 
		double sum = a+b;
		System.out.println("The sum of given two numbers is " + sum + ".");

	}

}
