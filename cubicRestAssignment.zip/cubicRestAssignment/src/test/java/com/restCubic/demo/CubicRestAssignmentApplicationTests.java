package com.restCubic.demo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CubicRestAssignmentApplicationTests {

	@Test
	void contextLoads() {
	}

}
