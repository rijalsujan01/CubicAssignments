package com.restCubic.demo.Entity;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Employee {

	@Id
	private long empId;
	private String name;
	private String gender;

	public Employee() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Employee(int id, String name, String gender) {
		super();
		this.empId = id;
		this.name = name;
		this.gender = gender;
	}

	public long getId() {
		return empId;
	}

	public void setId(long l) {
		this.empId = l;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	@Override
	public String toString() {
		return "Employee [id=" + empId + ", name=" + name + ", gender=" + gender + "]";
	}

}
