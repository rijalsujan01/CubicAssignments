package com.restCubic.demo.Repository;
import java.util.*;

import org.springframework.data.jpa.repository.JpaRepository;

import com.restCubic.demo.Entity.Employee;

@org.springframework.stereotype.Repository
public interface EmployeeRepository extends JpaRepository<Employee, Long> {
	List<Employee>findByOrderByGenderAsc();

}
