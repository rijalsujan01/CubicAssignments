package com.restCubic.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CubicRestAssignmentApplication {

	public static void main(String[] args) {
		SpringApplication.run(CubicRestAssignmentApplication.class, args);
	}

}
